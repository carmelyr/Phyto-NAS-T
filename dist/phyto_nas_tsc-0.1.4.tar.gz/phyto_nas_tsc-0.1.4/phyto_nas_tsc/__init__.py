from .core import fit
from .version import __version__

__all__ = ['fit', '__version__']